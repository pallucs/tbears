docker cp tbear:/work /home/palistha/Desktop/tbear
