
docker stop tbear
docker rm tbear
docker run -it --name=tbear -v tvol:/work -p 9000:9000 iconloop/tbears:mainnet
